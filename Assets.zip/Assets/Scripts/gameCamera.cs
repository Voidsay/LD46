﻿using UnityEngine;
/*
 * This script is supposed to frame the scene so that all important elements are visible
 */
public class gameCamera : MonoBehaviour
{

    public Transform[] poi;//points of intrest ("poi")
    public Vector3 offset = new Vector3(0, 0, 0);//camera offset
    public Vector3 scale = new Vector3(0, 0, -1);//dynamic scale
    public Vector3 max = new Vector3(0, 0, -100);//max dynamic scale


    // Start is called before the first frame update
    void Start()
    {
        //*this script is pointless unless we have at least one poi*//
        if (poi.Length < 1)
        {
            Debug.LogError("at least one object needed!");
        }
    }

    // Update is called once per frame
    void Update()
    {
        //*calculate the center between all pois*//
        transform.position = new Vector3(0, 0, 0);
        for (int i = 0; i < poi.Length; i++)
        {
            transform.position += 0.5f * poi[i].position;
        }

        //*limit dynamic scale*//
        if (transform.position.magnitude < max.magnitude)//buggy
        {
            transform.position += transform.position.magnitude * scale;
        }
        else
        {
            transform.position += max.magnitude * scale;
        }


        //*add offset*//
        transform.position += offset;
        //transform.position.Set(-transform.position.x, -transform.position.y, 0);
    }
}
