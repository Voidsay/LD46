﻿using UnityEngine;

public class movementP2 : MonoBehaviour
{


    public Rigidbody rb;
    public Transform tf;

    public float movementForce = 100;//sideways force strength
    public float min = -50;
    public float max = 0;
    public float grav = 10f;


    private Vector3 nextStep;
    //private bool pause;

    // Update is called once per frame
    // fixed updates are better for rigit bodys, or so I was told
    void FixedUpdate()
    {
        //*input handle*//
        if (Input.GetKey(KeyCode.RightArrow))
        {
            nextStep.Set(movementForce * Time.deltaTime, 0, 0);
            if ((tf.position + nextStep).x < max)
            {
                //rb.AddForce(nextStep, ForceMode.VelocityChange);
                tf.position += nextStep;
            }
        }
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            nextStep.Set(-movementForce * Time.deltaTime, 0, 0);
            if ((tf.position + nextStep).x > min)
            {
                //rb.AddForce(-movementForce * Time.deltaTime, 0, 0, ForceMode.VelocityChange);
                tf.position += nextStep;
            }
        }
        if (Input.GetKey(KeyCode.DownArrow))
        {
            rb.AddForce(0, -movementForce * Time.deltaTime, 0, ForceMode.VelocityChange);
        }

        if (tf.position.x < min)
        {
            tf.position = new Vector3(min, tf.position.y, tf.position.z);
        }
        if (tf.position.x > max)
        {
            tf.position = new Vector3(max, tf.position.y, tf.position.z);
        }

        rb.AddForce(0, -grav * Time.deltaTime, 0, ForceMode.VelocityChange);//extra gravity

    }


}