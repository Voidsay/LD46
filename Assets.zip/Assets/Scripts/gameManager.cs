﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class gameManager : MonoBehaviour
{
    private bool end = false;
    private bool recetable = true;

    public GameObject menu;
    public GameObject option;

    public Transform p1;
    public Transform p2;
    public Transform egg;

    public Rigidbody p1r;
    public Rigidbody p2r;
    public Rigidbody eggr;

    private Vector3 p1pos;
    private Vector3 p2pos;
    private Vector3 eggpos;

    private Quaternion p1rot;
    private Quaternion p2rot;
    private Quaternion eggrot;

    private bool menuState;

    public float restartdelay = 3f;

    public int P1S = 0;
    public int P2S = 0;


    public void gameover()
    {
        if (!end)
        {
            end = true;
            Debug.Log("game over");
            Invoke("restart", restartdelay);
        }
    }

    public void restart()
    {
        //SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
    void Start()
    {
        menuState = menu.activeInHierarchy;
        p1pos = p1.position;
        p1rot = p1.rotation;
        p2pos = p2.position;
        p2rot = p2.rotation;
        eggpos = egg.position;
        eggrot = egg.rotation;

    }

    void Update()
    {
        //Debug.Log(p1tf.position.ToString());
        if (Input.GetKey(KeyCode.Escape))
        {
            //if (menuState)
            //{
            menuOn();
            //}
            //else
            //{
            //    menuOff();
            //}
        }
    }

    private void menuOn()
    {
        menu.SetActive(true);
        Time.timeScale = 0;
    }

    public void menuOff()
    {
        menu.SetActive(false);
        Time.timeScale = 1;
    }

    public void mainMenu()
    {
        SceneManager.LoadScene("Main menu");
    }

    public void optionOn()
    {
        option.SetActive(true);
    }

    public void optionOff()
    {
        option.SetActive(false);
    }

    public void p1add()
    {
        if (recetable)
        {
            recetable = false;
            P1S++;
            Invoke("reset", restartdelay);
        }
    }
    public void p2add()
    {
        if (recetable)
        {
            recetable = false;

            P2S++;
            Invoke("reset", restartdelay);
        }
    }
    private void reset()
    {
        p1.position = p1pos;
        p1.rotation = p1rot;
        p2.position = p2pos;
        p2.rotation = p2rot;
        egg.position = eggpos;
        egg.rotation = eggrot;
        p1r.angularVelocity = new Vector3(0,0,0);
        p2r.angularVelocity = new Vector3(0, 0, 0);
        eggr.angularVelocity = new Vector3(0, 0, 0);
        p1r.velocity = new Vector3(0, 0, 0);
        p2r.velocity = new Vector3(0, 0, 0);
        eggr.velocity = new Vector3(0, 0, 0);
        recetable = true;

    }
}

