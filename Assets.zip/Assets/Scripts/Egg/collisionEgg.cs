﻿using UnityEngine;

public class collisionEgg : MonoBehaviour
{
    public Rigidbody rb;
    public AudioSource source;
    public AudioClip[] clip;

    void Start()
    {

    }

    void OnCollisionEnter(Collision collisionInfo)
    {
        if (collisionInfo.collider.tag == "envoirnment")
        {
            FindObjectOfType<gameManager>().gameover();
            //if (groundcollision.isPlaying)
            {
                source.clip = clip[0];
                source.Play();
            }
        }
        if (collisionInfo.collider.tag == "unit")
        {
            //rb.velocity = -2 * rb.velocity;
            //if (playercolision.isPlaying)
            {
                source.clip = clip[1];
                source.Play();
            }
        }

        if (collisionInfo.collider.tag == "net")
        {
            //rb.velocity = -2 * rb.velocity;
            //if (playercolision.isPlaying)
            {
                source.clip = clip[2];
                source.Play();
            }
        }
        if (collisionInfo.collider.tag == "celing")
        {
            Debug.Log("celing hit");
        }
    }
}
