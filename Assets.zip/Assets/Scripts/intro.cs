﻿using UnityEngine.SceneManagement;
using UnityEngine;

public class intro : MonoBehaviour
{

    public AudioSource source;
    public AudioClip[] clip;
    public float[] delay;
    public float offset = 0.5f;
    public float levelchange = 1f;

    private int count = 0;
    private float wait = 0;

    // Start is called before the first frame update
    void Start()
    {
        if (clip.Length != delay.Length)
        {
            Debug.LogError("source and delay count must be equal!");
        }

        for (int i = 0; i < clip.Length; i++)
        {
            wait += delay[i];
            Debug.Log("clip " + i + " delay " + wait);
            Invoke("playsound", wait);
            wait += clip[i].length + offset;
        }
        Invoke("toMenu", wait + levelchange);
    }

    void Update()
    {
        if (Input.GetKey(KeyCode.Escape) || Input.GetKey(KeyCode.Return) || Input.GetKey(KeyCode.KeypadEnter) || Input.GetKey(KeyCode.Space))
        {
            toMenu();
        }
    }

    private void playsound()
    {
        if (source.isPlaying)
        {
            Debug.LogError("sound still plays" + count);
        }
        Debug.Log("testaudio" + count);
        source.clip = clip[count];
        count++;
        source.Play();
    }

    private void toMenu()
    {
        Debug.Log("main menu");
        SceneManager.LoadScene("Main menu");
    }
}
