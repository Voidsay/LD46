﻿using UnityEngine;

public class jumpP1 : MonoBehaviour
{
    public Rigidbody rb;

    public float upForce = 100;//upward force strength
    public int maxup = 10;//max times upforce can be applied

    private int upcount = 0;// number of times upforce was applied

    // Update is called once per frame
    // fixed updates are better for rigit bodys, or so I was told
    void FixedUpdate()
    {

        if (Input.GetKey("w") && upcount < maxup)
        {
            upcount++;
            rb.AddForce(0, upForce * Time.deltaTime, 0, ForceMode.Impulse);
        }
        if (upcount >= maxup)
        {
            this.enabled = false;//disables jump
            upcount = 0;//reset counter
        }

    }
}
