﻿using UnityEngine;

public class collisionP1 : MonoBehaviour
{
    public jumpP1 jump;

    public AudioSource source;
    public AudioClip[] clip;

    void OnCollisionEnter(Collision collisionInfo)
    {
        if (collisionInfo.collider.tag == "envoirnment")
        {
            jump.enabled = true;//reenables jump on collision
            source.clip = clip[0];
            source.Play();
        }
    }
}
