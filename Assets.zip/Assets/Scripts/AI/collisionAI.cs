﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class collisionAI : MonoBehaviour
{
    public jumpAI jump;
    public AudioSource source;
    public AudioClip[] clip;

    void OnCollisionEnter(Collision collisionInfo)
    {
        if (collisionInfo.collider.tag == "envoirnment")
        {
            jump.enabled = true;//reenables jump on collision
            source.clip = clip[0];
            source.Play();
        }
        if (collisionInfo.collider.tag == "Egg")
        {
            Debug.Log("egg");
            jump.jumpNow();
        }
    }
}
