﻿using UnityEngine;


public class movementAI : MonoBehaviour
{

    public Rigidbody rb;//own rigit body
    public Transform tf;//own transform
    public Transform target;//target egg
    public Transform enemy;//human player or bot
    private Transform storage;
    public jumpAI jump;

    public float min = 0.5f;
    public float max = 50f;
    public float offset = 0.5f;
    public float wait = 0.5f;
    public float distance = 5;
    public float grav = 10f;

    private float dir = 0;

    private bool umlock = false;//movement unlocked

    private Vector3 nextStep;
    public Vector3 origin = new Vector3(0, 0, 0);

    public float movementForce = 100;//sideways force strength

    // Start is called before the first frame update
    void Start()
    {
        Invoke("unlock", wait);// locks movement for a moment
        if (enemy.position.x < origin.x)
        {
            dir = 1;
        }
        else
        {
            dir = -1;
        }
    }

    // Update is called once per frame
    // fixed updates are better for rigit bodys, or so I was told
    void FixedUpdate()
    {
        if (umlock)
        {
            //*input handle*//
            storage = target;
            if (target.position.x > max && target.position.x < min)
            {
                storage.position = new Vector3(5, 0, 0);
            }
            if (storage.position.x - offset * enemy.position.normalized.x > tf.position.x)
            {
                nextStep.Set(movementForce * Time.deltaTime, 0, 0);
                if ((tf.position + nextStep).x < max)
                {
                    //rb.AddForce(nextStep, ForceMode.VelocityChange);
                    tf.position += nextStep;
                }
            }
            if (storage.position.x - offset * enemy.position.normalized.x < tf.position.x)
            {
                nextStep.Set(-movementForce * Time.deltaTime, 0, 0);
                if ((tf.position + nextStep).x > min)
                {
                    //rb.AddForce(-movementForce * Time.deltaTime, 0, 0, ForceMode.VelocityChange);
                    tf.position += nextStep;
                }
            }
            if (jump.enabled == false)
            {
                //Debug.Log("down");
                rb.AddForce(0, -movementForce * Time.deltaTime, 0, ForceMode.VelocityChange);
            }


            if (tf.position.x < min - dir * distance)
            {
                jump.jumpNow();
            }

            if (tf.position.x < min)
            {
                tf.position = new Vector3(min, tf.position.y, tf.position.z);
            }
            if (tf.position.x > max)
            {
                tf.position = new Vector3(max, tf.position.y, tf.position.z);
            }
        }
        rb.AddForce(0, -grav * Time.deltaTime, 0, ForceMode.VelocityChange);//extra gravity
    }

    void unlock()
    {
        umlock = true;
    }

}
