﻿using UnityEngine;

public class TriggerP1 : MonoBehaviour
{
    public gameManager gameManager;
    void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Egg")
        {
            gameManager.p2add();
        }
    }
}
