﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class menu : MonoBehaviour
{

    public GameObject options;
    public GameObject newGame;
    public GameObject help;
    public GameObject credits;

    public void showOptions()
    {
        options.SetActive(true);
    }
    public void hideOptions()
    {
        options.SetActive(false);
    }

    public void showNewGame()
    {
        newGame.SetActive(true);
    }
    public void hideNewGame()
    {
        newGame.SetActive(false);
    }

    public void showHelp()
    {
        help.SetActive(true);
    }
    public void hideHelp()
    {
        help.SetActive(false);
    }

    public void showCredits()
    {
        credits.SetActive(true);
    }
    public void hideCredits()
    {
        credits.SetActive(false);
    }


    public void pvp()
    {
        Debug.Log("pvp");
        SceneManager.LoadScene("PvP");
    }

    public void pve()
    {
        Debug.Log("pve");
        SceneManager.LoadScene("PvE");
    }

    public void quit()
    {
        Debug.Log("exit");
        Application.Quit();
    }

}
